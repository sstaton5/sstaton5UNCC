# Linear Regression Exercise

## 1. Data Preparation
- **Dataset Size**: A subset of the data was used because the dataset contained more than 10,000 observations.
- **Dependent Variable (DV)**: A categorical DV was transformed into a binary variable for linear regression analysis.

## 2. Model Estimation
- Bivariate linear regression was estimated using the following command:
```r
stan_glm(DV ~ IV, data = subset_data)
```

## 3. Scatterplot with Regression Line
- The DV was plotted against the IV and a fitted regression line was added.
![scatterplot](./scatterplot_with_line.png)

- **Regression Equation**:
```
Y = Intercept + Coefficient * X
Example: Y = 2.35 + 0.45 * IV
```

## 4. Model Fit
- **R² (R-squared)**: Not found
## 5. Interpretation
- 5. Interpretation
- # Print interpretation